from os import system
from random import choice, seed
from lib.numerize import numerize
from time import sleep
from datetime import datetime

seed(datetime.now())

def main():
    dinero = 500
    apostar = 0
    color = ''
    while True:
        system("clear")
        print(
f"""Dinero actual: ${dinero}
Dinero a apostar: ${apostar}
Color: {color}

1. Elegir color
2. Modificar apuesta
3. Jugar
4. Salir

""")
        opt = numerize(input("Opción: "))
        if not opt: continue
        if opt == 1:
            print("\nColores: Rojo / Negro\n\n")
            opt = input("Escoge un color: ").lower()
            if opt in ('rojo', 'negro'):
                color = opt
            continue
        if opt == 2:
            mon = numerize(input("Dinero a apostar: $"))
            if mon:
                if mon <= dinero:
                    apostar += dinero
                    apostar = mon
                    dinero -= apostar
                continue
        if opt == 3:
            if not apostar:
                print("\nNo se ha apostado nada.")
                input("\nPresiona enter para continuar...")
                continue
            if not color:
                print("\nNo se ha elegido ningún color.")
                input("\nPresiona enter para continuar...")
                continue
            r = choice(('rojo', 'negro'))
            print("\nColor ganador: ", end="")
            sleep(2)
            print(r)
            if r == color:
                print("\t¡Excelente! Has duplicado lo que apostaste\n")
                dinero += apostar * 2
                apostar = 0
            else:
                print(f"\tOh no, has perdido esta ronda. Pierdes ${apostar//2}\n")
                dinero += apostar//2
                apostar = 0
            color = ''
            input("\nPresiona enter para continuar...")
            continue
        if opt == 4:
            exit(0)
        pass

if __name__ == '__main__':
    main()

