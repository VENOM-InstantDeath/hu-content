def numerize(n: str):
    if n.isdigit():
        return int(n)
    elif n.count(".") == 1:
        for i in n.split("."):
            if not i.isdigit():
                return None
        return float(n)
    else: return None
